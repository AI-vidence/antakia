
__version__ = "0.2.1"
__author__ = "AI-vidence "

from antakia.antakia import AntakIA