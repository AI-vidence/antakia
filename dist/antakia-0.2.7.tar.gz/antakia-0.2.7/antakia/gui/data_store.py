class DataStore:
    def __init__(
            self,
            X,
            y,
            X_test,
            y_test,
    ):
